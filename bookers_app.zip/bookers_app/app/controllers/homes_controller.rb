class HomesController < ApplicationController
  def top

  end

  def new

  end

  def book

  end
end
