require "test_helper"

class IndexTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
